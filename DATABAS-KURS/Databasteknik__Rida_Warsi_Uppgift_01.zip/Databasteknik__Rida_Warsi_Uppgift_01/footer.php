<footer class ="text-center">
    <hr>
    Copywrite &copy;
    <?php echo date('Y');
    ?>
    
    </footer>
</body>
</html>    