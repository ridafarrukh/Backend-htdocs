-----------REFLEKTIONER----------
Det var roligt att göra den här uppgiften.
Jag är nöjd med vad jag har gjort och det funkar bra.


